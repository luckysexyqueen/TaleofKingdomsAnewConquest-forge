package com.convallyria.taleofkingdoms.common.schematic;

public enum SchematicOptions {
    IGNORE_DEFENDERS,
    NO_ENTITIES,
    IGNORE_GATEWAY
}
