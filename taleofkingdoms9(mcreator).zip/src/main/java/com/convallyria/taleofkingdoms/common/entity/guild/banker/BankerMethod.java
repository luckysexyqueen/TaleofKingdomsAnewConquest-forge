package com.convallyria.taleofkingdoms.common.entity.guild.banker;

public enum BankerMethod {
    DEPOSIT,
    WITHDRAW
}
