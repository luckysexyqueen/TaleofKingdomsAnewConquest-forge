package com.convallyria.taleofkingdoms.common.entity;

public interface MovementVaried {

    boolean isMovementEnabled();

    void setMovementEnabled(boolean movementEnabled);
}
